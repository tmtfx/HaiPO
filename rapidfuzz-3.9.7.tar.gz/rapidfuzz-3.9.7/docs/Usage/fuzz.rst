rapidfuzz.fuzz
==============

ratio
-----
.. autofunction:: rapidfuzz.fuzz.ratio

partial_ratio
-------------
.. autofunction:: rapidfuzz.fuzz.partial_ratio

partial_ratio_alignment
-----------------------
.. autofunction:: rapidfuzz.fuzz.partial_ratio_alignment

token_set_ratio
---------------
.. autofunction:: rapidfuzz.fuzz.token_set_ratio

partial_token_set_ratio
-----------------------
.. autofunction:: rapidfuzz.fuzz.partial_token_set_ratio

token_sort_ratio
----------------
.. autofunction:: rapidfuzz.fuzz.token_sort_ratio

partial_token_sort_ratio
------------------------
.. autofunction:: rapidfuzz.fuzz.partial_token_sort_ratio

token_ratio
-----------
.. autofunction:: rapidfuzz.fuzz.token_ratio

partial_token_ratio
-------------------
.. autofunction:: rapidfuzz.fuzz.partial_token_ratio

WRatio
------
.. autofunction:: rapidfuzz.fuzz.WRatio

QRatio
------
.. autofunction:: rapidfuzz.fuzz.QRatio
