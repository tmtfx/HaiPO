Hamming
-------

Functions
^^^^^^^^^

distance
~~~~~~~~
.. autofunction:: rapidfuzz.distance.Hamming.distance

normalized_distance
~~~~~~~~~~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.Hamming.normalized_distance

similarity
~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.Hamming.similarity

normalized_similarity
~~~~~~~~~~~~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.Hamming.normalized_similarity
