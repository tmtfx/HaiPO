Prefix
-------

Functions
^^^^^^^^^

distance
~~~~~~~~
.. autofunction:: rapidfuzz.distance.Prefix.distance

normalized_distance
~~~~~~~~~~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.Prefix.normalized_distance

similarity
~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.Prefix.similarity

normalized_similarity
~~~~~~~~~~~~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.Prefix.normalized_similarity
